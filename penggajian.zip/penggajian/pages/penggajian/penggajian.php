<div id="top" class="row mb-3">
    <div class="col"></div>
        <h3>Penggajian</h3>
    </div>
    <div class="col">
        <a href="#" class="btn btn-success float-end">
            <i class="fa fa-plus-circle"></i>
            Tambah
        </a>
        <div class="col">
            <a href="?page=pilihbulantahunpenggajian" class="btn btn-primary float-end">
                <i class="fa fa-arrow-circle-left"></i>
                Kembali
            </a>
        </div>
    </div>
</div>
<div id="content" class="row mb-3">
    <div class="col">
        <?php  
        include('connection.php');

        $no = 1;
        $bulan = $_GET['bulan'];
        $tahun = $_GET['tahun'];

        $select_sql = "";
        if  ($bulan == "Semua") {
            if ($tahun == "Semua") {
            $select_sql = "SELECT P.*, K.nama FROM penggajian P
                LEFT JOIN karyawan ON karyawan_nik = K.nik";
       } else {
        $select_sql = "SELECT P.*, K.nama FROM penggajian P
                LEFT JOIN karyawan ON karyawan_nik = K.nik WHERE tahun = $tahun";
       }    
    } else {
        if ($tahun == "Semua") {
            $select_sql = "SELECT P.*, K.nama FROM penggajian P
                LEFT JOIN karyawan K ON P.karyawan_nik = K.nik WHERE tahun = $tahun AND bulan = '$bulan'";
    }
}

$result = mysqli_query($connection, $select_sql);
if (!$result) {
